import React from 'react';
import './App.css';
import Title from './components/title';
import MySidebar from './components/sidebar';
import Nameste from './components/main';

function App() {
  return (
    <div className="App">
      <Title/>
      <header className="App-header">
      <MySidebar/>
      <Nameste/>
      </header>
    </div>
  );
}

export default App;