import React from 'react';

function Nameste() {
    return ( 
        <p>
        109990009 沙馬太 LAB07
        </p>
    );
}

export default Nameste;