import './App.css';
import { Sidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import { Routes, Route, Outlet, Link, useSearchParams, useNavigate } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <Title />
      <MySidebar />
      <Routes>
		    <Route index element={<Home />} />
		    <Route path="search" element={<Search />} />
		    <Route path="*" element={<NoMatch />} />
      </Routes>
    </div>
  );
}

function Layout() {
  return (
    <div>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
			      <li>
              <Link to="/search?term">Search</Link>
            </li>
          </ul>
        </nav>
      <hr />
      <Outlet />
      </div>
    </div>
  );
}

function MySidebar() {
  return(
    <div>
    <Sidebar>
    <Menu>
      <MenuItem routerLink={<Link to="/"/>}> Home </MenuItem>
      <MenuItem routerLink={<Link to="search"/>}> Search </MenuItem>
    </Menu>
  </Sidebar>
  </div>
  )
}

function Title() {
  return(
    <div>
        <h3>Welcome to NTUT Web Programming!</h3>
    </div>
  )
}

function Home() {
  return (
    <div>
      <h2>Home</h2>
    </div>
  );
}

function NoMatch() {
  return (
    <div>
      <h2>Nothing to see here!</h2>
      <p>
        <Link to="/">Go to the home page</Link>
      </p>
    </div>
  );
}

function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    navigate('/search')
  };

  return (
    <div>
    <h2>Your search term: {searchParams.get('term')}</h2>
    <form onSubmit={handleSubmit}>
    <label for="ss">Search:</label>
      <input name="term"/>
      <button onClick={handleSubmit}>submit</button>
    </form>
  </div>
  );
}

export default App;
