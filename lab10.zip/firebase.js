import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database"


const firebaseConfig = {
    apiKey: "AIzaSyDknJbexMuGwPqS_EGXvjHkLEer-nqonTI",
    authDomain: "ntut-web-by-mjg-109990009.firebaseapp.com",
    databaseURL: "https://ntut-web-by-mjg-109990009-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "ntut-web-by-mjg-109990009",
    storageBucket: "ntut-web-by-mjg-109990009.appspot.com",
    messagingSenderId: "454171457635",
    appId: "1:454171457635:web:27b0d7118922b6c1eaa056"
};
const app = initializeApp(firebaseConfig);
export const database = getDatabase(app);